package com.pms.dao;

import java.util.List;

import com.pms.model.Product;

public interface ProductDao {
	public void addProduct(Product p) throws Exception;
	public void deleteProduct(int id);
	public List<Product> displayAllProducts() throws Exception;

}
