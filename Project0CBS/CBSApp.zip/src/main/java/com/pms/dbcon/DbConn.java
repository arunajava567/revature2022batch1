package com.pms.dbcon;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DbConn {
	
	public static Connection getConnection() throws ClassNotFoundException,SQLException,IOException
	{
		FileInputStream fileStream = new FileInputStream("E:\\Revature\\workspace\\CBSApp\\src\\main\\resources\\jdbc.properties"); 
		Properties properties = new Properties(); 
		properties.load(fileStream);
		String url = properties.getProperty("url");	
		String id = properties.getProperty("id"); 
		String pwd = properties.getProperty("pwd");
		
        Class.forName("com.mysql.cj.jdbc.Driver");//"com.mysql.jdbc.Driver"
		
		//2 creating connection
		
		Connection con=
		DriverManager.getConnection(url,id,pwd);
		
		return con;
	}

}
