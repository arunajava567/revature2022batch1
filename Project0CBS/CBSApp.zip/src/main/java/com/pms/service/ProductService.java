package com.pms.service;

import java.util.List;

import com.pms.model.Product;

public interface ProductService {

	public void addProduct(Product p) throws Exception;
	public void deleteProduct(int id);
	public List<Product> displayAllProducts() throws Exception;
	
}
