package com.pms.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

import com.pms.dao.ProducDaoImpl;
import com.pms.dao.ProductDao;
import com.pms.dbcon.DbConn;
import com.pms.model.Product;

public class ProductServiceImpl implements ProductService {
	 private static final Logger logger = Logger.getLogger("ProductServiceImpl.class");

	static ArrayList<Product> productList=new ArrayList<Product>();
	ProductDao ps=new ProducDaoImpl();
	public void addProduct(Product p) throws Exception {
		logger.info("adding...");
		ps.addProduct(p);
		
		logger.info("added successfully...in db as well");
	}
	
	public void deleteProduct(int id) {
		logger.info("entering into deleting,....");
		Iterator<Product> it=productList.iterator();
		while(it.hasNext()) {
			Product p=(Product)it.next();
			if(p.getProductId()==id)
				it.remove();
		}
	}
	
	public List<Product> displayAllProducts() throws Exception{
	 List<Product> plist=ps.displayAllProducts();
			return plist;
		
	}

}
