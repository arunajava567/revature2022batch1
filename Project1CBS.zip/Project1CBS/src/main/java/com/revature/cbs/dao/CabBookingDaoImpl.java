package com.revature.cbs.dao;

import com.revature.cbs.model.Cab;

public class CabBookingDaoImpl  implements CabBookingDao{

	
	public boolean addCabBooking(Cab cab ) {
		System.out.println(cab);
		System.out.println(" booking done");
		return true;
	}
}
