package com.revature.cbs.dao;

import com.revature.cbs.model.Cab;

public interface CabBookingDao {
	public boolean addCabBooking(Cab cab );
}
