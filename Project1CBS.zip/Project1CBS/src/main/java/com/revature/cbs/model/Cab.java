package com.revature.cbs.model;


public class Cab {
	
	Integer id;
	String model;
	String	time;
	String	dname;
	String dmobile;
	public Cab(Integer id, String model, String time, String dname, String dmobile) {
		super();
		this.id = id;
		this.model = model;
		this.time = time;
		this.dname = dname;
		this.dmobile = dmobile;
	}
	@Override
	public String toString() {
		return "Cab [id=" + id + ", model=" + model + ", time=" + time + ", dname=" + dname + ", dmobile=" + dmobile
				+ "]";
	}
	
	

}
