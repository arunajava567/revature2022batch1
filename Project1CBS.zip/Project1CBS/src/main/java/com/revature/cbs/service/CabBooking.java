package com.revature.cbs.service;

import com.revature.cbs.model.Cab;

public interface CabBooking {
	
	public boolean addCabBooking(Cab cab );

}
