
public class Cab {
	
	Integer id;
	String model;
	String	time;
	String	dname;
	String dmobile;
	

}
