var asyncOperation = function(){
    if(true)
        return Promise.resolve('async Success');
    else
        return Promise.reject('async Failed');
    
}
asyncOperation().then(function(res){
    console.log(res);
});

asyncOperation().catch(function(res){
    console.log("Error :",res);
});