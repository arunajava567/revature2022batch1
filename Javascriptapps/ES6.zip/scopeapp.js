var carName = "Volvo";  //global scope
myFunction();

function myFunction() {
  console.log(carName);  
}