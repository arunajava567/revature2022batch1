package pack2;

public class TimeExample {

	public void printResult() {
		System.out.println("This is an example to JUnit time test");
		while (true);
			
	}
}