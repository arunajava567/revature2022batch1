package pack2;

import static org.junit.Assert.*;

import org.junit.Test;

public class DivisionTest {
	
	Division division1 = new Division(10,2);
	Division division2 = new Division(10,0);

	@Test
	public void testResult() {
		assertEquals(5, division1.result());
	}
	
	@Test(expected= ArithmeticException.class)
	public void testResultwithException() {
		
		assertEquals(5, division2.result());
		
	}


}
