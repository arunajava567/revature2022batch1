package com;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import junit.framework.Test;
import junit.framework.TestSuite;
@RunWith(Suite.class)
@SuiteClasses(value={CalculatorTest.class,CalculatorTestbeforeafter.class,CalculatorTestExce.class})
public class AllTests {




}
