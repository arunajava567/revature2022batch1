package com;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class CalculatorTestbeforeafter {
	private Calculator c=null;
	@Before
	public void testPreparation()
	{
		c=new Calculator();
	}

	@Test
	public void testMul() {
		//fail("Not yet implemented");
		assertEquals(4,c.mul(4, 2));
	}
	@After
	public void testdeletion()
	{
		c=null;
	}

}
