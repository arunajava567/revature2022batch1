package com;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {
		//fail("Not yet implemented");
		Calculator c=new Calculator();
		assertEquals(4,c.add(2, 2));
	}

}
