package com;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTestExce {

	@Test()
	public void testDiv()throws ArithmeticException {
		//fail("Not yet implemented");
		try
		{
		Calculator c=new Calculator();
		c.div(4,0);
		}
		catch(ArithmeticException e)
		{
			assertEquals(e.getMessage(),"ArithmeticException");
		}
	}

}
