package com;

public class Calculator {
public int add(int a,int b)
{
	int c;
	c=a+b;
	return c;
}
public int mul(int a,int b)
{
	int c=a*b;
	return c;
}

public int div(int a,int b)
{
		
	int c=a/b;
		 
	
	 return c;
}
public int square(int a)
{
	int b=a*a;
	return b;
}
}
