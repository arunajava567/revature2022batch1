package com;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
@RunWith(value=Parameterized.class)
public class CalculatorTestPara {

	@Test
	public void testSquare() {
		//fail("Not yet implemented");
		
	}

}
