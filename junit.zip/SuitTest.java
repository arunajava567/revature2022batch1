package pack2;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({CalculateTest.class,AnnotationsTest.class,AssertionsTest.class})
public class SuitTest {

}
