package pack2;

import org.junit.Test;

public class TimeExampleTest {
	
	TimeExample timeExample = new TimeExample();
    //We have to specify time in milliseconds in @Test(timeout = timeInMilliSeconds) 
	@Test(timeout=1000)
	public void testPrintResult() {
		timeExample.printResult();
	}

}
