package pack2;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class AnnotationsTest {
	
	List list;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("@BeforeClass: onceExecutedBeforeAll");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		 System.out.println("@AfterClass: onceExecutedAfterAll");
	}

	@Before
	public void setUp() throws Exception {
		list= new ArrayList();
		System.out.println("@Before: executedBeforeEach");

		
	}

	@After
	public void tearDown() throws Exception {
		list.clear();
		System.out.println("@After: executedAfterEach");

	}

	@Test
	public void testOneItemCollection() {
		list.add("oneItem");
		assertEquals(1, list.size());
		System.out.println("@Test: testOneItemCollection");
		
	}
	@Ignore
	public void testexecutionIgnored() {
		 System.out.println("@Ignore: This execution is ignored");
	}

}
