package pack2;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTest {
	Calculate calculate;
	private int expected;
	private int first;
	private int second;

	public ParameterizedTest(int expected, int first, int second) {
		this.expected = expected;
		this.first = first;
		this.second = second;
	}

	@Parameters
	public static Collection<Integer[]> addedNumbers() {
		return Arrays.asList(new Integer[][] { { 3, 1, 2 }, { 5, 2, 3 }, { 7, 3, 4 }, { 9, 4, 5 }, });
	}

	@Before
	public void setUp() throws Exception {
		calculate = new Calculate();
		System.out.println("@Before: executedBeforeEach test case");
	}

	@Test
	public void testSum() {
		System.out.println("Addition with parameters : " + first + " and " + second+" ="+expected);
		assertEquals(expected, calculate.sum(first, second));
	}

}
