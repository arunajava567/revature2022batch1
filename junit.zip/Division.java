package pack2;

public class Division {
	
	int num1, num2;
	
	public Division(int num1, int num2){
		this.num1=num1;
		this.num2=num2;
	}
	
	public int result() throws ArithmeticException{
		
		return num1/num2;
	}

}
