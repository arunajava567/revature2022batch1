package pack2;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculateTest {

	Calculate calculate;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		 System.out.println("@BeforeClass: onceExecutedBeforeAll Test cases");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		 System.out.println("@AfterClass: onceExecutedAfterAll Test cases");
	}

	@Before
	public void setUp() throws Exception {
		calculate= new Calculate();
		System.out.println("@Before: executedBeforeEach test case");

	}

	@After
	public void tearDown() throws Exception {
		calculate=null;
		 System.out.println("@After: executedAfterEach");

	}

	@Test
	public void testSum() {
		//int sum = calculate.sum(2, 5);
		//int expectedValue=7; 
		System.out.println("@Test sum()");
		assertEquals(7,calculate.sum(2, 5));


		
	}

}
