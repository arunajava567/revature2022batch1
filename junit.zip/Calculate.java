package pack2;

public class Calculate {
	
	public int sum(int var1, int var2) {
		System.out.println("Sum: " + (var1 +var2));
		return var1 + var2;
	}
}
