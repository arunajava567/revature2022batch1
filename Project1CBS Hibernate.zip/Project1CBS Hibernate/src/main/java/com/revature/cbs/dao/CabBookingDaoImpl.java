package com.revature.cbs.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.revature.cbs.model.Cab;
import com.revature.util.HibernateDbCon;

public class CabBookingDaoImpl  implements CabBookingDao{

	
	public boolean addCabBooking(Cab cab ) {
		
		Session session=HibernateDbCon.getSessionFactory().openSession();
		
		Transaction tx= session.getTransaction();
		tx.begin();
		session.save(cab);
	
		
		tx.commit();
		session.close();
		System.out.println(cab);
		System.out.println(" booking done");
		return true;
	}
	
	
}
