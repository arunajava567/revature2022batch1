package com.revature.cbs.service;

import com.revature.cbs.dao.CabBookingDao;
import com.revature.cbs.dao.CabBookingDaoImpl;
import com.revature.cbs.model.Cab;

public class CabBookingImpl implements  CabBooking {
	CabBookingDao dao=new CabBookingDaoImpl();
	public boolean addCabBooking(Cab cab ) {
		dao.addCabBooking(cab);
		System.out.println(cab);
		System.out.println(" booking done");
		return true;
	}

}