package com.revature.cbs.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.revature.cbs.model.Cab;
import com.revature.cbs.service.CabBooking;
import com.revature.cbs.service.CabBookingImpl;

public class CabBookingServlet extends HttpServlet {
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	response.setContentType("text/html");
	PrintWriter out=response.getWriter();
	
	
	Integer id=Integer.parseInt(request.getParameter("id"));
	String model=request.getParameter("model");
	String	time=request.getParameter("time");
	String	dname=request.getParameter("dname");;
	String dmobile=request.getParameter("dmobile");;
	
	Cab cab=new Cab(id,model,time,dname,dmobile);
	HttpSession s=request.getSession(true);
	s.setAttribute("cab", cab);
	CabBooking cb=new CabBookingImpl();
	boolean result=cb.addCabBooking(cab);
	if(result) {
	RequestDispatcher rd=request.getRequestDispatcher("success");
	rd.include(request, response);
	}
	else
	{
		RequestDispatcher rd=request.getRequestDispatcher("unsuccess");
		rd.include(request, response);
	}
	}

}
