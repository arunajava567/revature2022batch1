package com.revature.cbs.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Cab {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer id;
	
	String model;
	String	time;
	String	dname;
	String dmobile;
	public Cab(Integer id, String model, String time, String dname, String dmobile) {
		super();
		this.id = id;
		this.model = model;
		this.time = time;
		this.dname = dname;
		this.dmobile = dmobile;
	}
	@Override
	public String toString() {
		return "Cab [id=" + id + ", model=" + model + ", time=" + time + ", dname=" + dname + ", dmobile=" + dmobile
				+ "]";
	}
	
	

}
