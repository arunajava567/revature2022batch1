package com.revature.cbs.exception;

public class CabNotAvailableException extends Exception {
	CabNotAvailableException(String msg) {
		super(msg);
	}

}
