
public class HibernateDbCon {

}
