
import javax.persistence.GenerationType;

@Entity
@Table
public class Cab {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	Integer id;
	
	String model;
	String	time;
	String	dname;
	String dmobile;
	
	
	
	Cab() {
		
	}
	

}
