package com.revature.cbs.dao.test;

import com.revature.cbs.dao.CabBookingDao;
import com.revature.cbs.dao.CabBookingDaoImpl;
import com.revature.cbs.model.Cab;

import junit.framework.TestCase;

public class CabBookingDaoImplTest extends TestCase {

	public void testAddCabBooking() {
		Cab cab=new Cab(101,"r","9am","raj","999999");
		CabBookingDao dao=new CabBookingDaoImpl();
		assertEquals(true,dao.addCabBooking(cab));
		
		//fail("Not yet implemented");
	}
	
	
	

}
