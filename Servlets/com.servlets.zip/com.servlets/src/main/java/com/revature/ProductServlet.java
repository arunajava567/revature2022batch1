package com.revature;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ProductServlet
 */
public class ProductServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("Welcome to Product Servlet");
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		int qty=Integer.parseInt(request.getParameter("qty"));
		int price=Integer.parseInt(request.getParameter("price"));
		Product product=new Product(id,name,qty,price);
		
		HttpSession session=request.getSession(true);
		session.setAttribute("p", product);
		session.setAttribute("app","Http Session Application");
		
		//out.print("<a href='DisplayServlet'>invoke Display Product</a>");   doGet
		
		RequestDispatcher rd=request.getRequestDispatcher("DisplayServlet");
		//rd.forward(request, response);
		rd.include(request, response);
	}

}
