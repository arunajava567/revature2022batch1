package com.revature;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class DisplayServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		HttpSession h=request.getSession(true);
		out.println(h.getAttribute("app").toString());
		Product p=(Product)h.getAttribute("p");
		
		out.println(p.getId());
		out.println(p.getName());
		out.println(p.getPrice());
		
		out.println(p.getQty());
		/*
		 * p.setQty(200); h.setAttribute("up",p); out.println(h.getAttribute("app"));
		 * out.println(h.getAttribute("app").toString()); Product
		 * updatedProduct=(Product)h.getAttribute("up");
		 * out.println(updatedProduct.getId()); out.println(updatedProduct.getName());
		 * out.println(updatedProduct.getPrice()); out.println(updatedProduct.getQty());
		 */
		
		
	
		
		
		
		
		
		
		
	}

}
