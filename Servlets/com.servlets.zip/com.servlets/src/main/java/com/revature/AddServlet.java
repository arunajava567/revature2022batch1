package com.revature;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		int n1=Integer.parseInt(request.getParameter("n1"));
		int n2=Integer.parseInt(request.getParameter("n2"));
		int sum=n1+n2;
			out.println("<h1>sum:  "+ sum+"</h1>");
			double a=sum/2;
		
			Double d=new Double(a);
			String ds=d.toString();
			out.println("<form action='Avgservlet' > <input type='hidden' name='a' value='"+a+"'><input type='submit' value='Invoke Avergae'></form>");
	
	
			out.print("<a href='Avgservlet?a=" + a + "'>display average value</a>");
			
			
			Cookie c=new Cookie("s",ds);
			
			response.addCookie(c);
	}
	

	

}
