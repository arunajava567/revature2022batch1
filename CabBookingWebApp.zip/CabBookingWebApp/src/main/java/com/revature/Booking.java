package com.revature;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Booking extends HttpServlet {
	ServletConfig config;
	public void init(ServletConfig config) throws ServletException{
		this.config=config;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<h1>Welcome to Cab booking App</h1>");
		out.println("Config: local:"+config.getInitParameter("drivername"));
		
		ServletContext context=config.getServletContext();
		out.println("Context param: global :"+context.getInitParameter("country"));
		
		String id=request.getParameter("id");
		String from=request.getParameter("from");
		String to=request.getParameter("to");
		String bookingtime=request.getParameter("bookingtime");
		
	    out.println(id+"   "+from +"  "+to +"   "+bookingtime);
		
		RequestDispatcher rd=request.getRequestDispatcher("Approved");
		rd.forward(request,response);
		//rd.include(request, response);
		
		
	}

}
